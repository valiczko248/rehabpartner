/* ===========================================================
   Rehab Partner Alapítvány — main.js
   Parallax, scroll-reveal, count-up, category filter,
   sticky header, scroll progress, mobile nav, form.
   All motion respects prefers-reduced-motion.
   =========================================================== */
(function () {
  'use strict';
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- sticky header + scroll progress + back-to-top ---------- */
  var header = document.getElementById('header');
  var progress = document.getElementById('scrollProgress');
  var toTop = document.getElementById('toTop');

  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop;
    if (header) header.classList.toggle('scrolled', y > 40);
    if (toTop) toTop.classList.toggle('show', y > 600);
    if (progress) {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- mobile nav ---------- */
  var navToggle = document.getElementById('navToggle');
  var mobileNav = document.getElementById('mobileNav');
  if (navToggle && mobileNav) {
    navToggle.addEventListener('click', function () {
      var open = mobileNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      navToggle.setAttribute('aria-label', open ? 'Menü bezárása' : 'Menü megnyitása');
    });
    mobileNav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        mobileNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------- scroll reveal (IntersectionObserver) ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    reveals.forEach(function (el) { el.classList.add('in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          // stagger within a shared parent grid
          var sibs = Array.prototype.slice.call(e.target.parentElement.children).filter(function (c) { return c.classList.contains('reveal'); });
          var idx = sibs.indexOf(e.target);
          e.target.style.transitionDelay = Math.min(idx, 6) * 70 + 'ms';
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    reveals.forEach(function (el) { io.observe(el); });
    // Safety net: never let content stay hidden if the observer misses
    // (e.g. timeline throttled in a background tab). Force-reveal after a grace period.
    window.addEventListener('load', function () {
      setTimeout(function () {
        document.querySelectorAll('.reveal:not(.in)').forEach(function (el) { el.classList.add('in'); });
      }, 2600);
    });
  }

  /* ---------- count-up stats ---------- */
  var counters = document.querySelectorAll('.stat-num');
  function animateCount(el) {
    var target = parseInt(el.getAttribute('data-count'), 10) || 0;
    if (reduceMotion) { el.textContent = target.toLocaleString('hu-HU'); return; }
    var start = null, dur = 1500;
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.floor(eased * target).toLocaleString('hu-HU');
      if (p < 1) requestAnimationFrame(step);
      else el.textContent = target.toLocaleString('hu-HU');
    }
    requestAnimationFrame(step);
  }
  if ('IntersectionObserver' in window) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { animateCount(e.target); cio.unobserve(e.target); }
      });
    }, { threshold: 0.5 });
    counters.forEach(function (c) { cio.observe(c); });
  } else {
    counters.forEach(animateCount);
  }

  /* ---------- category filter ---------- */
  var chips = document.querySelectorAll('.chip');
  var cards = document.querySelectorAll('.cat-card');
  var emptyMsg = document.getElementById('catEmpty');
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('active'); c.setAttribute('aria-selected', 'false'); });
      chip.classList.add('active');
      chip.setAttribute('aria-selected', 'true');
      var f = chip.getAttribute('data-filter');
      var shown = 0;
      cards.forEach(function (card) {
        var match = (f === 'all' || card.getAttribute('data-cat') === f);
        card.classList.toggle('hide', !match);
        if (match) shown++;
      });
      if (emptyMsg) emptyMsg.hidden = shown !== 0;
    });
  });

  /* ---------- parallax (GSAP ScrollTrigger if available, else rAF fallback) ---------- */
  function initParallax() {
    var layers = document.querySelectorAll('[data-parallax]');
    if (reduceMotion || !layers.length) return;

    if (window.gsap && window.ScrollTrigger) {
      gsap.registerPlugin(ScrollTrigger);
      layers.forEach(function (el) {
        var depth = parseFloat(el.getAttribute('data-parallax')) || 0.2;
        gsap.to(el, {
          yPercent: depth * 100,
          ease: 'none',
          scrollTrigger: { trigger: el.closest('section') || el, start: 'top bottom', end: 'bottom top', scrub: true }
        });
      });
    } else {
      // lightweight fallback
      window.addEventListener('scroll', function () {
        var vh = window.innerHeight;
        layers.forEach(function (el) {
          var depth = parseFloat(el.getAttribute('data-parallax')) || 0.2;
          var rect = el.getBoundingClientRect();
          var offset = (rect.top + rect.height / 2 - vh / 2);
          el.style.transform = 'translate3d(0,' + (-offset * depth) + 'px,0)' + (el.classList.contains('hero-bg') ? ' scale(1.12)' : '');
        });
      }, { passive: true });
    }
  }
  // GSAP is loaded with defer; ensure it's ready
  if (window.gsap) initParallax();
  else window.addEventListener('load', initParallax);

  /* ---------- contact form (graceful: Formspree if configured, else mailto) ---------- */
  var form = document.getElementById('contactForm');
  var status = document.getElementById('formStatus');
  if (form) {
    form.addEventListener('submit', function (ev) {
      var action = form.getAttribute('action') || '';
      var configured = action && action.indexOf('YOUR_FORM_ID') === -1;
      if (!configured) {
        // fallback to mailto so the form is never a dead end before endpoint setup
        ev.preventDefault();
        var fd = new FormData(form);
        var body = 'Név: ' + (fd.get('name') || '') + '\n'
          + 'Telefon: ' + (fd.get('phone') || '') + '\n'
          + 'E-mail: ' + (fd.get('email') || '') + '\n'
          + 'Kategória: ' + (fd.get('category') || '') + '\n\n'
          + (fd.get('message') || '');
        window.location.href = 'mailto:rehabpartner7@gmail.com?subject='
          + encodeURIComponent('Ajánlatkérés a weboldalról') + '&body=' + encodeURIComponent(body);
        if (status) { status.textContent = 'Megnyitottuk levelezőjét az üzenet elküldéséhez.'; status.className = 'form-status ok'; }
        return;
      }
      // Async submit to Formspree
      ev.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      if (btn) { btn.disabled = true; btn.textContent = 'Küldés…'; }
      fetch(action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
        .then(function (r) {
          if (r.ok) {
            form.reset();
            if (status) { status.textContent = 'Köszönjük üzenetét! Hamarosan jelentkezünk.'; status.className = 'form-status ok'; }
          } else { throw new Error('hiba'); }
        })
        .catch(function () {
          if (status) { status.textContent = 'Sajnos hiba történt. Kérjük, hívjon minket: +36 70 604 3463'; status.className = 'form-status err'; }
        })
        .finally(function () { if (btn) { btn.disabled = false; btn.textContent = 'Üzenet küldése'; } });
    });
  }

  /* set current year in footer if needed (kept static 2026) */
})();
